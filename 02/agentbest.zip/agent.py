#!/usr/bin/python3
'''
Very simple example how to use gym_wrapper and BaseAgent class for state space search 
@author: Zdeněk Rozsypálek, and the KUI-2019 team
@contact: svobodat@fel.cvut.cz
@copyright: (c) 2017, 2018, 2019
'''

import time
import kuimaze
import os
import random
import queue
import math
import copy


class Agent(kuimaze.BaseAgent):
    '''
    Agent class that inherits kuimaze.BaseAgent class 
    '''
    def __init__(self, environment):
        self.environment = environment

    def calc_path_cost(self, positions, goal, g, path):    #function for calculating prices
        eval_pos = []
        for i in positions:                                #for each node

            coords, one_move_dist = i                      # calculate g(x) 

            new_g = g + one_move_dist 

            x_dist = coords[0] - goal[0]
            y_dist = coords[1] - goal[1]
            h = math.sqrt((x_dist)**2 + (y_dist)**2)       # calculate h(x) 

            F = g + (1*h)                               # calculate F(x) = g(x) + h(x)

            new_path = copy.deepcopy(path)
            new_path.append(coords)
            
            eval_pos.append((F, new_g, h, coords, new_path))                   # creation of evaluated node + adding to a list
        return eval_pos                                                        # returns a list with evaluated nodes


    def find_path(self):
        '''
        returns a path_section as a list of positions [(x1, y1), (x2, y2), ... ].
        '''
        observation = self.environment.reset() 
        goal = observation[1][0:2]
        position = observation[0][0:2]                                         # initial state (x, y) = position
        print("Starting random searching")
        prior_queue = []
        expanded = []
        path = [position]
        g = 0
        full_position = (0, 0, 0, position, path)

        # A* algorithm
        while True:
            new_positions = self.environment.expand(position)         # returns [[(x1, y1), cost], [(x2, y2), cost], ... ]
            expanded.append(position)
            #print(new_positions)
            newer_positions = [self.calc_path_cost(new_positions, goal, full_position[1], full_position[4])]   

            if not prior_queue:
                    prior_queue.append(newer_positions[0][0])
            cnt = 0
            for i in newer_positions[0]: 
                if i[3] in expanded:
                    continue
                for index, j in enumerate(prior_queue): 
                    if i[3] == j[3]:
                        cnt +=1
                        if j[0] > i[0]:
                            prior_queue[index] = i                           
                        elif j[0] == i[0]:
                            if j[1] > i[1]:
                                prior_queue[index] = i
                if cnt == 0:    
                    prior_queue.append(i)
                cnt = 0
                                      
            prior_queue.sort(key = lambda prior_queue: prior_queue[0])  
            for k in prior_queue:
                if k not in expanded:  
                    full_position = prior_queue.pop(0)          # select first not expanded from priotity queue 
                    break
            
            position = full_position[3]       
            
            #print(position)                                           
            if position == goal:                    # break the loop when the goal position is reached
                print("goal reached")
                break
            #self.environment.render()               # show enviroment's GUI       DO NOT FORGET TO COMMENT THIS LINE BEFORE FINAL SUBMISSION!      
            #time.sleep(0.1)                         # sleep for demonstartion     DO NOT FORGET TO COMMENT THIS LINE BEFORE FINAL SUBMISSION! 

        return full_position[4]               #prikaz pro vytisknuti cesty z baseagent.find_path


if __name__ == '__main__':

    MAP = 'maps/normal/normal9.bmp'
    MAP = os.path.join(os.path.dirname(os.path.abspath(__file__)), MAP)
    GRAD = (0, 0)
    SAVE_PATH = False
    SAVE_EPS = False

    env = kuimaze.InfEasyMaze(map_image=MAP, grad=GRAD)       # For using random map set: map_image=None
    agent = Agent(env) 

    path = agent.find_path()
    print(path)
    env.set_path(path)          # set path it should go from the init state to the goal state
    if SAVE_PATH:
        env.save_path()         # save path of agent to current directory
    if SAVE_EPS:
        env.save_eps()          # save rendered image to eps
    env.render(mode='human')
    time.sleep(3)
